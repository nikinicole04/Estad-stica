library(readxl)

dataset <- read_excel("Data/dataset.xlsx", 
                      sheet = "MatrizDatos")
View(dataset)


Sexo <- dataset$Sexo
NHerm <- dataset$Nherm
Estat <- dataset$Estat
Divert <- dataset$Divert

Sexo_c <- factor(x = Sexo,
                 labels = c("Hombre", "Mujer"),
                 ordered = FALSE)
Sexo_c

table(Divert)
Divert_c <- factor(x = Divert,
                   labels = c("En desacuerdo",
                              "Indeciso",
                              "De acuerdo"),
                   ordered = TRUE)
Divert_c
